// The example class categories definitions for Doxygen

/// \file Doxymodules_radioactivedecay.h
/// \brief The page that defines the extended/radioactivedecay examples modules 


/** @defgroup extended_radioactivedecay radioactivedecay
 *  Extended examples eventgenerator classes
 *  @{
 */

/** @defgroup extended_radioactivedecay_Activation Activation
 *  radioactivedecay Activation example has its
 *  <a href="../html_Activation/html/index.html">standalone documentation </a>
 *  @ingroup extended_radioactivedecay
 *  @{
 */

/** @} */

/** @defgroup extended_radioactivedecay_rdecay01 rdecay01
 *  radioactivedecay rdecay01 example has its
 *  <a href="../html_rdecay01/html/index.html">standalone documentation </a>
 *  @ingroup extended_radioactivedecay
 *  @{
 */

/** @} */

/** @defgroup extended_radioactivedecay_rdecay02 rdecay02
 *  radioactivedecay rdecay02 example has its
 *  <a href="../html_rdecay02/html/index.html">standalone documentation </a>
 *  @ingroup extended_radioactivedecay
 *  @{
 */

/** @} */

/** @} */
